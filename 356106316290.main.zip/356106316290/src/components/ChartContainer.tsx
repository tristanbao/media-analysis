import { ReactNode, useState } from 'react';

interface ChartContainerProps {
  title: string;
  children: ReactNode;
  description?: string;
  className?: string;
  onSearch?: (value: string) => void;
  searchPlaceholder?: string;
}

export default function ChartContainer({
  title,
  children,
  description,
  className = '',
  onSearch,
  searchPlaceholder = '搜索...',
}: ChartContainerProps) {
  const [searchValue, setSearchValue] = useState('');

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchValue(value);
    if (onSearch) {
      onSearch(value);
    }
  };

  return (
    <div className={`bg-white rounded-xl shadow-md p-5 ${className}`}>
      <div className="flex justify-between items-center mb-4 flex-wrap gap-3">
        <div>
          <h3 className="text-lg font-bold text-gray-800">{title}</h3>
          {description && <p className="text-sm text-gray-500 mt-1">{description}</p>}
        </div>
        <div className="flex items-center space-x-2">
          {onSearch && (
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                <i className="fa-solid fa-search text-gray-400"></i>
              </span>
              <input
                type="text"
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#002060] focus:border-[#002060] w-64 transition-all duration-300"
                placeholder={searchPlaceholder}
                value={searchValue}
                onChange={handleSearchChange}
              />
            </div>
          )}
          <button className="p-1 text-gray-400 hover:text-gray-600">
            <i className="fa-solid fa-ellipsis-vertical"></i>
          </button>
        </div>
      </div>
      <div className="h-[300px] w-full">
        {children}
      </div>
    </div>
  );
}