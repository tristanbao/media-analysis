import { useState } from 'react';
import { toast } from 'sonner';
import Layout from '../../components/Layout';
import TableContainer from '../../components/TableContainer';
import { battleAnalysisData } from '../../data/marketingEffectData';

export default function SupplierAnalysis() {
  const [selectedSupplier, setSelectedSupplier] = useState<string | null>(null);

  // 处理风险任务数点击
  const handleRiskTaskClick = (supplierName: string, riskCount: number) => {
    setSelectedSupplier(supplierName);
    toast(`查看${supplierName}的${riskCount}个风险任务`);
    // 这里可以根据需要打开详情模态框或跳转到详情页面
  };

  // 结算资料状态样式
  const SettlementStatusTag = ({ status }: { status: string }) => {
    let className = '';
    let textClass = '';
    
    switch (status) {
      case '已完成':
        className = 'bg-green-100';
        textClass = 'text-green-800';
        break;
      case '审核中':
        className = 'bg-blue-100';
        textClass = 'text-blue-800';
        break;
      case '已提交':
        className = 'bg-amber-100';
        textClass = 'text-amber-800';
        break;
      default:
        className = 'bg-gray-100';
        textClass = 'text-gray-800';
    }
    
    return (
      <span className={`${className} ${textClass} text-xs px-2 py-1 rounded-full`}>
        {status}
      </span>
    );
  };

  return (
    <Layout title="供应商分析">
      <TableContainer title="供应商列表" description="各供应商的合同、结算与风险情况">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">供应商</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">合同金额</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">结算金额</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">支付金额</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">结算资料</th>
                <th scope="col" className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">风险任务数</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {battleAnalysisData.supplierData.map((supplier) => (
                <tr key={supplier.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{supplier.name}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{supplier.contractAmount}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{supplier.settlementAmount}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{supplier.paymentAmount}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <SettlementStatusTag status={supplier.settlementDocuments} />
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-center">
                    <button
                      onClick={() => handleRiskTaskClick(supplier.name, supplier.riskTasks)}
                      className={`text-sm font-medium ${
                        supplier.riskTasks > 0 ? 'text-red-600 hover:text-red-800' : 'text-gray-500'
                      } ${supplier.riskTasks > 0 ? 'underline cursor-pointer' : ''}`}
                      disabled={supplier.riskTasks === 0}
                    >
                      {supplier.riskTasks}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </TableContainer>
    </Layout>
  );
}