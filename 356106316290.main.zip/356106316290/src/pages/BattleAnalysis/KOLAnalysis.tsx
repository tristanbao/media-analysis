import { useState } from 'react';
import Layout from '../../components/Layout';
import TableContainer from '../../components/TableContainer';
import { battleAnalysisData } from '../../data/marketingEffectData';

// 标记指标的好坏
const getMetricClass = (value: number | string, type: 'views' | 'likes' | 'comments' | 'positiveRatio' | 'cpc') => {
  // 转换为数字
  const numValue = typeof value === 'string' ? parseFloat(value) : value;
  
  switch (type) {
    case 'views':
      // 播放量低于50万标记为低
      return numValue < 500000 ? 'bg-red-50 text-red-600 font-medium' : '';
    case 'likes':
      // 点赞量低于1万标记为低
      return numValue < 10000 ? 'bg-red-50 text-red-600 font-medium' : '';
    case 'comments':
      // 评论量低于200标记为低
      return numValue < 200 ? 'bg-red-50 text-red-600 font-medium' : '';
    case 'positiveRatio':
      // 正面占比低于60%标记为低
      return numValue < 60 ? 'bg-red-50 text-red-600 font-medium' : '';
    case 'cpc':
      // CPC高于30元标记为高
      return numValue > 30 ? 'bg-red-50 text-red-600 font-medium' : '';
    default:
      return '';
  }
};

// 渲染异常特征标签
const renderAnomalyTags = (anomalies: string[]) => {
  if (!anomalies || anomalies.length === 0) {
    return <span className="text-xs text-gray-500">无异常</span>;
  }
  
  const anomalyColors: Record<string, string> = {
    '无品牌露出': 'bg-red-100 text-red-800',
    '未提及产品': 'bg-orange-100 text-orange-800',
    '内容低俗': 'bg-pink-100 text-pink-800',
    '机器人流量': 'bg-purple-100 text-purple-800',
    '流量堆砌': 'bg-indigo-100 text-indigo-800',
    '虚假曝光': 'bg-blue-100 text-blue-800',
    '客群偏离': 'bg-teal-100 text-teal-800',
  };
  
  return (
    <div className="flex flex-wrap gap-1">
      {anomalies.map((anomaly, index) => (
        <span 
          key={index} 
          className={`text-xs px-2 py-1 rounded-full ${anomalyColors[anomaly] || 'bg-gray-100 text-gray-800'}`}
        >
          {anomaly}
        </span>
      ))}
    </div>
  );
};

// 增强KOL数据，添加异常特征
const enhanceKOLData = (kolData: any[]) => {
  const anomalyOptions = ['无品牌露出', '未提及产品', '内容低俗', '机器人流量', '流量堆砌', '虚假曝光', '客群偏离'];
  
  return kolData.map((kol) => {
    // 根据数据特征添加异常标签
    const anomalies: string[] = [];
    
    // CPC高的KOL可能有流量堆砌或机器人流量问题
    if (kol.cpc > 50) {
      anomalies.push('机器人流量');
      if (Math.random() > 0.5) {
        anomalies.push('流量堆砌');
      }
    }
    
    // 正面占比低的KOL可能有内容问题
    const positiveRatio = typeof kol.positiveRatio === 'string' ? parseFloat(kol.positiveRatio) : kol.positiveRatio;
    if (positiveRatio < 50) {
      anomalies.push('内容低俗');
    }
    
    // 随机添加一些其他异常
    if (Math.random() > 0.6 && anomalies.length < 3) {
      const randomAnomaly = anomalyOptions[Math.floor(Math.random() * anomalyOptions.length)];
      if (!anomalies.includes(randomAnomaly)) {
        anomalies.push(randomAnomaly);
      }
    }
    
    return {
      ...kol,
      anomalies
    };
  });
};

export default function KOLAnalysis() {
  const [selectedPlatform, setSelectedPlatform] = useState('xiaohongshu');

  // 平台选项
  const platforms = [
    { value: 'xiaohongshu', label: '小红书' },
    { value: 'douyin', label: '抖音' },
    { value: 'weibo', label: '微博' },
    { value: 'baidu', label: '百度' },
    { value: 'wechat', label: '微信视频号' },
  ];

  // 获取当前平台的KOL数据并增强
  const rawKOLData = battleAnalysisData.kolData[selectedPlatform as keyof typeof battleAnalysisData.kolData] || battleAnalysisData.kolData.xiaohongshu;
  const currentKOLData = enhanceKOLData(rawKOLData);

  return (
    <Layout title="KOL分析">
      <TableContainer 
        title="KOL效果分析" 
        description="各平台KOL的营销效果数据"
        actions={
          <div className="flex space-x-2">
            {platforms.map(platform => (
              <button
                key={platform.value}
                onClick={() => setSelectedPlatform(platform.value)}
                className={`px-3 py-1 text-sm rounded-md transition-colors ${
                  selectedPlatform === platform.value 
                    ? 'bg-[#002060] text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {platform.label}
              </button>
            ))}
          </div>
        }
      >
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">序号</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">达人昵称</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">营销投入</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">播放量</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">点赞量</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">评论量</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">正面占比</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">CPC</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">主要异常特征</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {currentKOLData.map((kol, index) => (
                <tr key={kol.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{index + 1}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{kol.name}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{kol.marketingExpense}</td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right ${getMetricClass(kol.views, 'views')}`}>
                    {kol.views.toLocaleString()}
                  </td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right ${getMetricClass(kol.likes, 'likes')}`}>
                    {kol.likes.toLocaleString()}
                  </td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right ${getMetricClass(kol.comments, 'comments')}`}>
                    {kol.comments.toLocaleString()}
                  </td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right ${getMetricClass(kol.positiveRatio, 'positiveRatio')}`}>
                    {kol.positiveRatio}
                  </td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right ${getMetricClass(kol.cpc, 'cpc')}`}>
                    {kol.cpc}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {renderAnomalyTags(kol.anomalies)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </TableContainer>
    </Layout>
  );
}