import { useState } from 'react';
import Layout from '../../components/Layout';
import TableContainer from '../../components/TableContainer';
import { battleAnalysisData } from '../../data/marketingEffectData';

// 渲染异常特征标签
const renderAnomalyTags = (anomalies: string[]) => {
  if (!anomalies || anomalies.length === 0) {
    return <span className="text-xs text-gray-500">无异常</span>;
  }
  
  const anomalyColors: Record<string, string> = {
    '客群偏离': 'bg-blue-100 text-blue-800',
    '内容缺少热度': 'bg-orange-100 text-orange-800',
    '代言人不匹配': 'bg-purple-100 text-purple-800',
    '表达不清': 'bg-red-100 text-red-800',
    '不符合品牌调性': 'bg-pink-100 text-pink-800',
  };
  
  return (
    <div className="flex flex-wrap gap-1">
      {anomalies.map((anomaly, index) => (
        <span 
          key={index} 
          className={`text-xs px-2 py-1 rounded-full ${anomalyColors[anomaly] || 'bg-gray-100 text-gray-800'}`}
        >
          {anomaly}
        </span>
      ))}
    </div>
  );
};

// 增强的素材数据，添加播放量、完播率和异常特征
const enhancedMaterialData = {
  'EH设计师视频': [
    {
      id: 1,
      media: '小红书',
      startDate: '2026-08-01',
      views: 1250000,
      completionRate: '85.3%',
      positiveRatio: '85%',
      neutralRatio: '10%',
      negativeRatio: '5%',
      evaluation: '表现优秀，用户反馈积极',
      analysis: '视频展示了产品的设计细节和功能性，用户对设计风格和保暖效果评价较高。建议增加更多场景化展示。',
      anomalies: [],
    },
    {
      id: 2,
      media: '抖音',
      startDate: '2026-08-15',
      views: 2870000,
      completionRate: '78.6%',
      positiveRatio: '82%',
      neutralRatio: '12%',
      negativeRatio: '6%',
      evaluation: '表现良好，互动率较高',
      analysis: '视频节奏紧凑，重点突出，在抖音平台获得了较高的互动。建议优化视频标题和封面以提高点击率。',
      anomalies: ['内容缺少热度'],
    },
    {
      id: 3,
      media: '微博',
      startDate: '2026-09-01',
      views: 950000,
      completionRate: '72.1%',
      positiveRatio: '78%',
      neutralRatio: '15%',
      negativeRatio: '7%',
      evaluation: '表现一般，需要优化',
      analysis: '内容较为专业，但传播性不足。建议增加更多用户使用场景和真实体验分享。',
      anomalies: ['客群偏离', '表达不清'],
    },
  ],
  '功能CG视频': [
    {
      id: 1,
      media: '抖音',
      startDate: '2026-08-10',
      views: 3240000,
      completionRate: '82.5%',
      positiveRatio: '88%',
      neutralRatio: '9%',
      negativeRatio: '3%',
      evaluation: '表现优秀，视觉效果震撼',
      analysis: 'CG视频展示了产品的科技感和功能性，视觉冲击力强，吸引了大量用户观看和互动。',
      anomalies: [],
    },
    {
      id: 2,
      media: '微信视频号',
      startDate: '2026-08-20',
      views: 1850000,
      completionRate: '76.3%',
      positiveRatio: '84%',
      neutralRatio: '12%',
      negativeRatio: '4%',
      evaluation: '表现良好，分享率高',
      analysis: 'CG效果在微信视频号平台受到用户喜爱，转发分享率较高，但互动评论相对较少。',
      anomalies: ['客群偏离'],
    },
  ],
  '于适音综热点CUT': [
    {
      id: 1,
      media: '抖音',
      startDate: '2026-08-25',
      views: 5680000,
      completionRate: '90.2%',
      positiveRatio: '92%',
      neutralRatio: '7%',
      negativeRatio: '1%',
      evaluation: '表现卓越，热点效应明显',
      analysis: '结合热点音综内容，利用明星效应，获得了极高的曝光和互动，有效提升了品牌关注度。',
      anomalies: [],
    },
    {
      id: 2,
      media: '微博',
      startDate: '2026-08-26',
      views: 4120000,
      completionRate: '87.6%',
      positiveRatio: '90%',
      neutralRatio: '8%',
      negativeRatio: '2%',
      evaluation: '表现卓越，话题性强',
      analysis: '在微博平台形成了热门话题，讨论度高，用户互动积极，有效提升了品牌影响力。',
      anomalies: [],
    },
  ],
  '张艺凡音综热点CUT': [
    {
      id: 1,
      media: '小红书',
      startDate: '2026-09-05',
      views: 2890000,
      completionRate: '83.5%',
      positiveRatio: '89%',
      neutralRatio: '8%',
      negativeRatio: '3%',
      evaluation: '表现优秀，用户喜爱度高',
      analysis: '张艺凡的形象与品牌定位契合，在小红书平台获得了大量年轻用户的喜爱和互动。',
      anomalies: [],
    },
    {
      id: 2,
      media: '抖音',
      startDate: '2026-09-06',
      views: 4350000,
      completionRate: '88.7%',
      positiveRatio: '91%',
      neutralRatio: '7%',
      negativeRatio: '2%',
      evaluation: '表现卓越，传播效果好',
      analysis: '视频内容有趣且符合抖音平台用户喜好，获得了高播放量和互动率，传播效果显著。',
      anomalies: ['不符合品牌调性'],
    },
  ],
};

export default function MaterialAnalysis() {
  const [selectedMaterial, setSelectedMaterial] = useState('EH设计师视频');

  // 素材选项
  const materials = [
    { value: 'EH设计师视频', label: 'EH设计师视频' },
    { value: '功能CG视频', label: '功能CG视频' },
    { value: '于适音综热点CUT', label: '于适音综热点CUT' },
    { value: '张艺凡音综热点CUT', label: '张艺凡音综热点CUT' },
  ];

  // 获取当前素材的数据
  const currentMaterialData = enhancedMaterialData[selectedMaterial] || enhancedMaterialData['EH设计师视频'];

  // 格式化播放量显示
  const formatViews = (views: number) => {
    if (views >= 10000) {
      return `${(views / 10000).toFixed(1)}万`;
    }
    return views.toString();
  };

  return (
    <Layout title="素材分析">
      {/* 素材选择和表格 */}
      <TableContainer 
        title="素材效果分析" 
        description="各素材在不同媒介的投放效果"
        actions={
          <div className="flex space-x-2">
            {materials.map(material => (
              <button
                key={material.value}
                onClick={() => setSelectedMaterial(material.value)}
                className={`px-3 py-1 text-sm rounded-md transition-colors ${
                  selectedMaterial === material.value 
                    ? 'bg-[#002060] text-white' 
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {material.label}
              </button>
            ))}
          </div>
        }
      >
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">投放媒介</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">投放开始时间</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">播放量</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">完播率</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">正面评价占比</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">中性评价占比</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">负面评价占比</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">投放评价</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">原因分析</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">主要异常特征</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {currentMaterialData.map((material) => (
                <tr key={material.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{material.media}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{material.startDate}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right font-medium text-gray-700">{formatViews(material.views)}</td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right font-medium ${
                    parseFloat(material.completionRate) >= 80 ? 'text-green-600' : 'text-amber-600'
                  }`}>{material.completionRate}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right font-medium text-green-600">{material.positiveRatio}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right font-medium text-amber-600">{material.neutralRatio}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right font-medium text-red-600">{material.negativeRatio}</td>
                  <td className="px-4 py-3 text-sm text-gray-700">{material.evaluation}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{material.analysis}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {renderAnomalyTags(material.anomalies)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </TableContainer>


    </Layout>
  );
}