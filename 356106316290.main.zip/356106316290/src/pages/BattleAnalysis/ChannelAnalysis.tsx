import Layout from '../../components/Layout';
import TableContainer from '../../components/TableContainer';
import { battleAnalysisData } from '../../data/marketingEffectData';

// 标记指标的好坏
const getMetricClass = (value: number | string, type: 'exposure' | 'ctr' | 'cpc') => {
  // 转换为数字
  const numValue = typeof value === 'string' ? parseFloat(value) : value;
  
  switch (type) {
    case 'exposure':
      // 曝光量低于1000万标记为低
      return numValue < 1000 ? 'bg-red-50 text-red-600 font-medium' : '';
    case 'ctr':
      // CTR低于2%标记为低
      return numValue < 2 ? 'bg-red-50 text-red-600 font-medium' : '';
    case 'cpc':
      // CPC高于3元标记为高
      return numValue > 3 ? 'bg-red-50 text-red-600 font-medium' : '';
    default:
      return '';
  }
};

// 渲染异常特征标签
const renderAnomalyTags = (anomalies: string[]) => {
  if (!anomalies || anomalies.length === 0) {
    return <span className="text-xs text-gray-500">无异常</span>;
  }
  
  const anomalyColors: Record<string, string> = {
    '机器人流量': 'bg-purple-100 text-purple-800',
    '流量堆砌': 'bg-red-100 text-red-800',
    '虚假曝光': 'bg-orange-100 text-orange-800',
    '客群偏离': 'bg-blue-100 text-blue-800',
  };
  
  return (
    <div className="flex flex-wrap gap-1">
      {anomalies.map((anomaly, index) => (
        <span 
          key={index} 
          className={`text-xs px-2 py-1 rounded-full ${anomalyColors[anomaly] || 'bg-gray-100 text-gray-800'}`}
        >
          {anomaly}
        </span>
      ))}
    </div>
  );
};

// 增强渠道数据，添加异常特征
const enhanceChannelData = () => {
  const anomalyOptions = ['机器人流量', '流量堆砌', '虚假曝光', '客群偏离'];
  
  return battleAnalysisData.channelAnalysisData.map((channel, index) => {
    // 根据数据特征添加异常标签
    const anomalies: string[] = [];
    
    // CPC高的渠道可能有流量堆砌问题
    if (channel.cpc > 5) {
      anomalies.push('流量堆砌');
    }
    
    // CTR特别低的渠道可能有虚假曝光问题
    const ctrValue = typeof channel.ctr === 'string' ? parseFloat(channel.ctr) : channel.ctr;
    if (ctrValue < 1) {
      anomalies.push('虚假曝光');
    }
    
    // 随机添加一些其他异常
    if (index % 4 === 0 && anomalies.length < 2) {
      const randomAnomaly = anomalyOptions[Math.floor(Math.random() * anomalyOptions.length)];
      if (!anomalies.includes(randomAnomaly)) {
        anomalies.push(randomAnomaly);
      }
    }
    
    return {
      ...channel,
      anomalies
    };
  });
};

export default function ChannelAnalysis() {
  const enhancedChannelData = enhanceChannelData();
  
  return (
    <Layout title="投放渠道分析">
      <TableContainer title="投放渠道效果分析" description="各投放渠道的曝光、点击率与转化成本">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">投放渠道</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">投放说明</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">投放周期</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">曝光（万）</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">CTR</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">CPC</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">主要异常特征</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {enhancedChannelData.map((channel) => (
                <tr key={channel.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{channel.channel}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{channel.description}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{channel.period}</td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right ${getMetricClass(channel.exposure, 'exposure')}`}>
                    {channel.exposure}
                  </td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right ${getMetricClass(channel.ctr, 'ctr')}`}>
                    {channel.ctr}
                  </td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right ${getMetricClass(channel.cpc, 'cpc')}`}>
                    {channel.cpc}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    {renderAnomalyTags(channel.anomalies)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </TableContainer>
    </Layout>
  );
}