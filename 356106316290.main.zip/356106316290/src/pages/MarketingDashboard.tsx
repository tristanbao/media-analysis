import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function MarketingDashboard() {
  const navigate = useNavigate();
  const [activeModule, setActiveModule] = useState('marketing-expense');

  const handleModuleClick = (module: string) => {
    setActiveModule(module);
    navigate(`/${module}`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航栏 */}
      <header className="bg-[#002060] text-white shadow-lg">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <i className="fa-solid fa-chart-line text-2xl"></i>
            <h1 className="text-xl font-bold">波司登市场营销分析看板</h1>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm">当前日期: 2026-04-02</span>
            <div className="flex items-center space-x-1">
              <i className="fa-regular fa-user-circle"></i>
              <span>管理员</span>
            </div>
          </div>
        </div>
      </header>

      {/* 主内容区 */}
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* 营销投入总览卡片 */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`bg-white rounded-xl shadow-md p-6 cursor-pointer transition-all duration-300 ${
              activeModule === 'marketing-expense' ? 'border-2 border-[#002060] shadow-lg' : 'hover:shadow-lg'
            }`}
            onClick={() => handleModuleClick('marketing-expense')}
          >
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-lg font-bold text-gray-800 mb-2">营销投入总览</h2>
                <p className="text-gray-600 text-sm mb-4">分析营销费用结构与变动趋势</p>
                <div className="flex space-x-2">
                  <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">费用分析</span>
                  <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">趋势分析</span>
                </div>
              </div>
              <div className="bg-blue-50 p-3 rounded-full">
                <i className="fa-solid fa-money-bill-wave text-[#002060] text-xl"></i>
              </div>
            </div>
          </motion.div>

          {/* 营销效果总览卡片 */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`bg-white rounded-xl shadow-md p-6 cursor-pointer transition-all duration-300 ${
              activeModule === 'marketing-effect' ? 'border-2 border-[#002060] shadow-lg' : 'hover:shadow-lg'
            }`}
            onClick={() => handleModuleClick('marketing-effect')}
          >
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-lg font-bold text-gray-800 mb-2">营销效果总览</h2>
                <p className="text-gray-600 text-sm mb-4">评估品牌声量与营销活动效果</p>
                <div className="flex space-x-2">
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">声量分析</span>
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">战役评估</span>
                </div>
              </div>
              <div className="bg-green-50 p-3 rounded-full">
                <i className="fa-solid fa-chart-pie text-[#00A651] text-xl"></i>
              </div>
            </div>
          </motion.div>

          {/* 以叠变应万变战役分析卡片 */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className={`bg-white rounded-xl shadow-md p-6 cursor-pointer transition-all duration-300 ${
              activeModule === 'battle-analysis' ? 'border-2 border-[#002060] shadow-lg' : 'hover:shadow-lg'
            }`}
            onClick={() => handleModuleClick('battle-analysis')}
          >
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-lg font-bold text-gray-800 mb-2">以叠变应万变战役分析</h2>
                <p className="text-gray-600 text-sm mb-4">深入分析特定战役的投入产出</p>
                <div className="flex space-x-2 flex-wrap">
                  <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full">供应商</span>
                  <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full">渠道</span>
                  <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full">KOL</span>
                  <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full">素材</span>
                </div>
              </div>
              <div className="bg-purple-50 p-3 rounded-full">
                <i className="fa-solid fa-crosshairs text-purple-600 text-xl"></i>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}