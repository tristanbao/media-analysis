import { useMemo } from 'react';
import { motion } from 'framer-motion';
import {
  LineChart, Line, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import Layout from '../components/Layout';
import StatCard from '../components/StatCard';
import ChartContainer from '../components/ChartContainer';
import WordCloud from '../components/WordCloud';
import TableContainer from '../components/TableContainer';
import { marketingEffectOverviewData } from '../data/marketingEffectData';

// 格式化数字显示
const formatNumber = (num: number) => {
  if (num >= 100000000) {
    return `${(num / 100000000).toFixed(2)}亿`;
  } else if (num >= 10000) {
    return `${(num / 10000).toFixed(2)}万`;
  }
  return num.toString();
};

// 自定义tooltip
const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-3 border border-gray-200 rounded shadow-md">
        <p className="font-medium text-gray-800">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={`item-${index}`} className="text-sm" style={{ color: entry.color }}>
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

// 状态标签样式
const StatusTag = ({ status }: { status: string }) => {
  let className = '';
  let textClass = '';
  
  switch (status) {
    case '进行中':
      className = 'bg-blue-100';
      textClass = 'text-blue-800';
      break;
    case '已结束':
      className = 'bg-gray-100';
      textClass = 'text-gray-800';
      break;
    case '未开始':
      className = 'bg-amber-100';
      textClass = 'text-amber-800';
      break;
    default:
      className = 'bg-gray-100';
      textClass = 'text-gray-800';
  }
  
  return (
    <span className={`${className} ${textClass} text-xs px-2 py-1 rounded-full`}>
      {status}
    </span>
  );
};

export default function MarketingEffectOverview() {
  // 准备品牌声量趋势数据
  const brandVoiceTrendData = useMemo(() => {
    return marketingEffectOverviewData.brandVoiceTrendData.map(item => ({
      month: item.month.replace('-', '/'),
      '波司登': item['波司登'],
      '迪桑特': item['迪桑特'],
      '始祖鸟': item['始祖鸟'],
      '凯乐石': item['凯乐石'],
      '高梵': item['高梵'],
      '鸭鸭': item['鸭鸭'],
    }));
  }, []);

  return (
    <Layout title="营销效果总览">
      {/* 顶部指标卡片 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <StatCard
          title={marketingEffectOverviewData.metrics[0].title}
          value={marketingEffectOverviewData.metrics[0].value}
          change={marketingEffectOverviewData.metrics[0].change}
          isPositive={marketingEffectOverviewData.metrics[0].isPositive}
          icon={marketingEffectOverviewData.metrics[0].icon}
          iconColor={marketingEffectOverviewData.metrics[0].iconColor}
        />
        
        {/* 总曝光量 */}
        <StatCard
          title={marketingEffectOverviewData.metrics[1].title}
          value={marketingEffectOverviewData.metrics[1].value}
          change={marketingEffectOverviewData.metrics[1].change}
          isPositive={marketingEffectOverviewData.metrics[1].isPositive}
          icon={marketingEffectOverviewData.metrics[1].icon}
          iconColor={marketingEffectOverviewData.metrics[1].iconColor}
        />
      </div>

      {/* 第二行 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* 声量变动趋势 */}
        <ChartContainer title="品牌声量变动趋势" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={brandVoiceTrendData}
              margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="month" />
              <YAxis tickFormatter={(value) => formatNumber(value)} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line type="monotone" dataKey="波司登" stroke="#002060" strokeWidth={2} activeDot={{ r: 8 }} />
              <Line type="monotone" dataKey="迪桑特" stroke="#3165B1" strokeWidth={2} />
              <Line type="monotone" dataKey="始祖鸟" stroke="#5285D5" strokeWidth={2} />
              <Line type="monotone" dataKey="凯乐石" stroke="#73A5E9" strokeWidth={2} />
              <Line type="monotone" dataKey="高梵" stroke="#94C5FD" strokeWidth={2} />
              <Line type="monotone" dataKey="鸭鸭" stroke="#B5E5FF" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </ChartContainer>
        
        {/* 总曝光量媒介分布 */}
        <ChartContainer title="总曝光量媒介分布">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={marketingEffectOverviewData.exposureMediaDistribution}
              margin={{ top: 10, right: 30, left: 0, bottom: 60 }}
              layout="vertical"
            >
              <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
              <XAxis type="number" tickFormatter={(value) => formatNumber(value)} />
              <YAxis 
                dataKey="name" 
                type="category" 
                width={80} 
                tick={{ fontSize: 12 }}
                interval={0}
              />
              <Tooltip 
                formatter={(value) => [`${value.toLocaleString()} 次`, '曝光量']}
                labelFormatter={(label) => `${label}`}
              />
              <Bar dataKey="value" fill="#3165B1" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </div>

      {/* 战役列表 */}
      <TableContainer title="战役列表" description="各营销战役的关键指标表现">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">战役名称</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">期间</th>
                <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">状态</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">营销投入合计</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">销量</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">营销费率</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">总曝光</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">热搜/热点数</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">爆文数</th>
                <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">新客数</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {marketingEffectOverviewData.battleList.map((battle, index) => (
                <tr key={index} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{battle.name}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">{battle.period}</td>
                  <td className="px-4 py-3 whitespace-nowrap">
                    <StatusTag status={battle.status} />
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{battle.marketingExpense}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{battle.sales}</td>
                  <td className={`px-4 py-3 whitespace-nowrap text-sm text-right ${
                    parseFloat(battle.marketingExpenseRate) <= 18 ? 'text-green-600 font-medium' : 'text-red-600 font-medium'
                  }`}>
                    {battle.marketingExpenseRate}
                  </td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{battle.totalExposure}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{battle.hotTopics}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{battle.viralPosts}</td>
                  <td className="px-4 py-3 whitespace-nowrap text-sm text-right text-gray-500">{battle.newCustomers}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </TableContainer>
    </Layout>
  );
}