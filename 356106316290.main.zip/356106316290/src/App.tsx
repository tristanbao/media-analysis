import { Routes, Route } from "react-router-dom";
import MarketingDashboard from "@/pages/MarketingDashboard";
import MarketingExpenseOverview from "@/pages/MarketingExpenseOverview";
import MarketingEffectOverview from "@/pages/MarketingEffectOverview";
import BattleAnalysis from "@/pages/BattleAnalysis";
import SupplierAnalysis from "@/pages/BattleAnalysis/SupplierAnalysis";
import ChannelAnalysis from "@/pages/BattleAnalysis/ChannelAnalysis";
import KOLAnalysis from "@/pages/BattleAnalysis/KOLAnalysis";
import MaterialAnalysis from "@/pages/BattleAnalysis/MaterialAnalysis";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<MarketingDashboard />} />
      <Route path="/marketing-expense" element={<MarketingExpenseOverview />} />
      <Route path="/marketing-effect" element={<MarketingEffectOverview />} />
      <Route path="/battle-analysis" element={<BattleAnalysis />} />
      <Route path="/battle-analysis/supplier" element={<SupplierAnalysis />} />
      <Route path="/battle-analysis/channel" element={<ChannelAnalysis />} />
      <Route path="/battle-analysis/kol" element={<KOLAnalysis />} />
      <Route path="/battle-analysis/material" element={<MaterialAnalysis />} />
    </Routes>
  );
}
